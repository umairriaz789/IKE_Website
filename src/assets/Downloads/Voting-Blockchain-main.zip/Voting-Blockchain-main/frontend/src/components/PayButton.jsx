import { useSelector } from "react-redux";

const PayButton = () => {
  return (
    <>
      <button>Explore on Blockchain</button>
    </>
  );
};

export default PayButton;
