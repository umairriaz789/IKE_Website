const mongoose = require("mongoose");

const electionSchema = new mongoose.Schema(
  {
    uid: {type: String},
    CityName: { type: String,required: true, minlength: 3, maxlength: 10240 },
    RegisterVotter:{type: Number},
    TotalGroups:{type: Number},
    ElectionDate: {type: Date,required: true},
    StartTime: {type: Date,required: true},
    EndTime: {type: Date,required: true},
    winnerGroupId:{type: Number},
    TxHash: {type: String},
    Groups: {type: [Object]},
  },
  { timestamps: true }
);

const Election = mongoose.model("Election", electionSchema);

exports.Election = Election;
