export const HR = () => {
	return (
		<div
			style={{
				width: "100%",
				height: "3px",
				background:
					"linear-gradient(270deg, #EDC452 0.26%, #846424 99.99%, #846424 100%), #846424",
				borderRadius: "40px",
			}}
		></div>
	);
};

