export const CCheckbox = () => {
	return (
		<input
			type="checkbox"
			style={{
				transform: "scale(1.5)",
				accentColor: "#EDC452",
			}}
		/>
	);
};
