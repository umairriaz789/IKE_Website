import { CHCForm } from "./chcform";

export const MintCHC = () => {
	return (
		<>
			<CHCForm />
		</>
	);
};
