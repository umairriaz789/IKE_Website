export { Dash1 } from "./dash1";
