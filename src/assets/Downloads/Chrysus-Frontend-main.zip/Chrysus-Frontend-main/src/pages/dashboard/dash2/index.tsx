export { Dash2 } from "./dash2";
