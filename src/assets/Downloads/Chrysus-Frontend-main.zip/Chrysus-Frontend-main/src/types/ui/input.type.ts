export type InputOutline = "FORM" | "PRIMARY";

export interface CSelectOption {
    icon: React.ReactNode;
    title: string;
    subTitle: string;
}