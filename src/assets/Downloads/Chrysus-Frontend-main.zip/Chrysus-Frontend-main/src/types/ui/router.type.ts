export interface CLink {
    label: string;
    url: string;
}
export interface CIconLink {
    url: string;
    icon: React.ReactNode;
}