export const COLORS = {
    primary: '#846424',
    secondary: '#6c757d',
    success: '#198754',
    info: '#0dcaf0',
    warning: '#ffc107',
    danger: '#dc3545',
    light: '#f8f9fa',
    dark: '#212529',
    white: '#fff',
    teal: '#20c997',
    leftbar_background: '#262522'
}