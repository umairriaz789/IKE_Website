export interface FormView {
    title: string;
    widget: string;
}

export type FormViews = FormView[];