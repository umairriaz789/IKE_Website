export type ThemeLight = 'theme-light';
export type ThemeDark = 'theme-dark';


export type Theme = ThemeLight | ThemeDark;