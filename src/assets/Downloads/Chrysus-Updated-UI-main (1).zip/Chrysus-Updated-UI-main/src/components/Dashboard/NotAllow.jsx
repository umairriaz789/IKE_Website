import React from 'react'

const NotAllow = () => {
    return (
        <div>
            {
                <div className=" mt-5 text ">
                    <h1 className="display-2 ml-5 text-center fw-bold text-Black">
                        Access <br />
                        is <span className="text-gradient">Denied....</span>

                    </h1>

                </div>
            }
        </div>
    )
}

export default NotAllow