import React from "react";
import VcardComingSoon from "./VcardComingSoon";

const VirtualCard = () => {
  return <VcardComingSoon />;
};

export default VirtualCard;
